<?php 
	session_start();
    
    include("ConnectEntDB.php");

	if (isset($_SESSION['AccID']))
	{
        $AccountID = $_SESSION['AccID'];
	}
	else
	{
		header("Location:logout.php");
	}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>PlanIT</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="fonts/icomoon/style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/jquery-ui.css">

  <link rel="stylesheet" href="css/style.css">



</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">
  
	<div class="py-2 bg-light">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-3 text-right">
            <a href="logout.php" class="small mr-3"><span class="icon-unlock-alt"></span> Log Out</a>
          </div>
        </div>
      </div>
    </div>

    
    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">

      <div class="container">
        <div class="d-flex align-items-center">
    
          <div class="mr-auto">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li class="active">
                  <a href="administrator.php" class="nav-link text-left">Home</a>
                </li>
                <li class="has-children">
                  <a href="#" class="nav-link text-left">Venue</a>
                  <ul class="dropdown">
                    <li><a href="AddV.php">Add Venue</a></li>
                    <li><a href="venue.php">Edit Venue</a></li>
					<li><a href="delV.php">Delete Venue</a></li>
                  </ul>
                </li>
                <li class="has-children">
                  <a href="#" class="nav-link text-left">Performer</a>
                  <ul class="dropdown">
                    <li><a href="addP.php">Add Performer</a></li>
                    <li><a href="perf.php">Edit Performer</a></li>
					<li><a href="delP.php">Delete Performer</a></li>
                  </ul>
                </li>
				<li class="has-children">
                  <a href="#" class="nav-link text-left">Our Organizer</a>
                  <ul class="dropdown">
                    <li><a href="addO.php">Add Organizer</a></li>
                    <li><a href="org.php">Edit Organizer</a></li>
					<li><a href="delO.php">Delete Organizer</a></li>
                  </ul>
                </li>
                <li class="has-children">
                  <a href="#" class="nav-link text-left">Schedule</a>
                  <ul class="dropdown">
                    <li><a href="addE.php">Add Event</a></li>
                    <li><a href="event.php">Edit Event</a></li>
					<li><a href="delE.php">Delete Event</a></li>
                  </ul>
                </li>
				 <li class="has-children">
                  <a href="#" class="nav-link text-left">User</a>
                  <ul class="dropdown">
                    <li><a href="addU.php">Add User</a></li>
                    <li><a href="customer.php">Edit User</a></li>
					<li><a href="delU.php">Delete User</a></li>
                  </ul>
                </li>
				<li class="has-children">
                  <a href="#" class="nav-link text-left">Accounts</a>
                  <ul class="dropdown">
                    <li><a href="accounts.php">Edit account</a></li>
					<li><a href="delA.php">Delete account</a></li>
                  </ul>
                </li>
              </ul>                                                                                                                                                                                                                                                                                          </ul>
            </nav>

          </div>
          <div class="ml-auto">
            <div class="social-wrap">
              <a href="#"><span class="icon-facebook"></span></a>
              <a href="#"><span class="icon-twitter"></span></a>
              <a href="#"><span class="icon-linkedin"></span></a>

              <a href="#" class="d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black"><span
                class="icon-menu h3"></span></a>
            </div>
          </div>
         
        </div>
      </div>

    <div class="site-section">
        <div class="container">
		<div class="site-section">
      <div class="container">
        <div class="row mb-5 justify-content-center text-center">
          <div class="col-lg-4 mb-5">
            <h2 class="section-title-underline mb-5">
              <span>Add New Event</span>
            </h2>
          </div>
        </div>
		<form action="PostE.php" method='POST'>
			<div class="row">
                <div class="col-md-6 form-group">
                    <label for="Type">Type</label>
					<input type="text" class="form-control" id="Type" name="Type" placeholder=' Event Type'  required>
                </div>
                <div class="col-md-6 form-group">
                    <label for="Name">Name</label>
                   <input type="text" class="form-control" id="Name" name="Name" placeholder='Event Name'  required>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="Expected">Expected Audience</label>
					<input type="text" class="form-control" id="Expected" name="Expected" placeholder='Expected Audience'  required>
                </div>
                <div class="col-md-6 form-group">
                    <label for="Actual">Actual Audience</label>
                   <input type="text" class="form-control" id="Actual" name="Actual" placeholder='Actual Audience'  required>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="StartD">Start Date</label>
                    <input type="text" class="form-control" id="StartD" name="StartD" placeholder='Year-Month-date'  required>
                </div>
                <div class="col-md-6 form-group">
                    <label for="EndD">End Date</label>
                    <input type="text" class="form-control" id="EndD" name="EndD" placeholder='Year-Month-date'  required>
                </div>
            </div>
			<div class="row">
                <div class="col-md-6 form-group">
                    <label for="StartT">Start Time</label>
                    <input type="text" class="form-control" id="StartT" name="StartT" placeholder='01:00:00'  required>
                </div>
                <div class="col-md-6 form-group">
                    <label for="EndT">End Time</label>
                    <input type="text" class="form-control" id="EndT" name="EndT" placeholder='01:00:00'  required>
                </div>
            </div>
			<div class="row">
                <div class="col-md-6 form-group">
                    <label for="ticket">ticket</label>
                    <input type="text" class="form-control" id="ticket" name="ticket" placeholder='ticket'  required>
                </div>
				<div class="col-md-6 form-group">
                    <label for="Profit">Profit</label>
                    <input type="text" class="form-control" id="Profit" name="Profit" placeholder='Profit'  required>
                </div>
            </div>
			<div class="row">
                <div class="col-md-6 form-group">
                    <label for="Notes">Notes</label>
					<input type="text" class="form-control" id="Notes" name="Notes" placeholder='Notes for requests'  required>
                </div>
				<div class="col-md-6 form-group">
                    <label for="pMaterials">Promotion Material</label>
					<input type="text" class="form-control" id="pMaterials" name="pMaterials" placeholder='promotional material'  required>
                </div>
            </div>
			<div class="row">
						<div class="col-md-6 form-group">
                            <label for="userID">USER:</label>
                          <select name="userID">
                    <?php
                    
                    $user = 'SELECT UID,firstName,lastName FROM user';
                    $res = $conn->query($user) or die('Error! Cound not run query: '.$conn->error);
                    if ($res->num_rows > 0){
                      while ($row=$res->fetch_assoc()){
                        echo "
                            <option value='".$row["UID"]."'>".$row["firstName"]." ".$row["lastName"]."</option>'
                        
                    ";
                      }
                    }

                    echo "</select>
                        </div>
                        </div>";
                    ?>
                    <div class="row">
						<div class="col-md-6 form-group">
                            <label for="perfID">Performer:</label>
                          <select name="perfID">
                    <?php
                    
                    $perf = 'SELECT PID,FName,LName FROM performer';
                    $res1 = $conn->query($perf) or die('Error! Cound not run query: '.$conn->error);
                    if ($res1->num_rows > 0){
                      while ($row=$res1->fetch_assoc()){
                        echo "
                            <option value='".$row["PID"]."'>".$row["FName"]." ".$row["LName"]."</option>'
                        
                    ";
                      }
                    }

                    echo "</select>
                        </div>
                        </div>";
                    ?>
                    <div class="row">
						<div class="col-md-6 form-group">
                            <label for="venID">Venue:</label>
                          <select name="venID">
                    <?php
                    
                    $ven = 'SELECT VID,Name FROM venue';
                    $res2 = $conn->query($ven) or die('Error! Cound not run query: '.$conn->error);
                    if ($res2->num_rows > 0){
                      while ($row=$res2->fetch_assoc()){
                        echo "
                            <option value='".$row["VID"]."'>".$row["Name"]."</option>'
                        
                    ";
                      }
                    }

                    echo "</select>
                        </div>
                        </div>";
                    ?>
					<div class="row">
						<div class="col-md-6 form-group">
                            <label for="orgID">Organizer:</label>
                          <select name="orgID">
                    <?php
                    
                    $org = 'SELECT OID,PfirstName, PlastName FROM organizer';
                    $res3 = $conn->query($org) or die('Error! Cound not run query: '.$conn->error);
                    if ($res3->num_rows > 0){
                      while ($row=$res3->fetch_assoc()){
                        echo "
                            <option value='".$row["OID"]."'>".$row["PfirstName"]." ".$row["PlastName"]."</option>'
                        
                    ";
                      }
                    }

                    echo "</select>
                        </div>
                        </div>";
                    ?>
            <div class="row">
                <div class="col-12">
                    <input type="submit" value="Add Event" class="btn btn-primary btn-lg px-5">
                </div>
            </div>
        </div>
    </div>


  </div>

  <script src="js/main.js"></script>

</body>

</html>