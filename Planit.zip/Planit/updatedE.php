<?php
		include("ConnectEntDB.php");
			$EID=$_POST["SID"];
            $Type=$_POST["Type"];
            $Name=$_POST["Name"];
            $Expected=$_POST["Expected"];
            $Actual=$_POST["Actual"];
            $StartD=$_POST["StartD"];
            $EndD=$_POST["EndD"];
            $StartT=$_POST["StartT"];
			$EndT=$_POST["EndT"];
			$Notes=$_POST["Notes"];
			$ticket=$_POST["ticket"];
			$Profit=$_POST["Profit"];
			$pMaterials=$_POST["pMaterials"];
			$PID=$_POST["perfID"];
			$VID=$_POST["venID"];
			$OID=$_POST["orgID"];
			$UID=$_POST["userID"];
			

            $sql = "UPDATE performer SET Type='$Type', Name='$Name', Expected='$Expected', Actual='$Actual', StartD='$StartD', EndD='$EndD', StartT='$StartT' , EndT='$EndT', Notes='$Notes', ticket='$ticket', pMaterials='$pMaterials', Profit='$Profit', UID='$UID', PID='$PID', OID='$OID', VID='$VID' WHERE SID='$EID' ";
            
            $res1 = $conn->query($sql) or die('Error: could not run query: '.$conn->error);
            echo "<h2 style='text-align:center'>Event Updated.<h2>";
            $conn->close();
            header("Location:event.php");
        ?>