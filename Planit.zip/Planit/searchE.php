<?php 
	session_start();
    
    include("ConnectEntDB.php");

	if (isset($_SESSION['AccID']))
	{
        $AccountID = $_SESSION['AccID'];
	}
	else
	{
		header("Location:logout.php");
	}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>PlanIT</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="fonts/icomoon/style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/jquery-ui.css">

  <link rel="stylesheet" href="css/style.css">



</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">
  
	<div class="py-2 bg-light">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-3 text-right">
            <a href="logout.php" class="small mr-3"><span class="icon-unlock-alt"></span> Log Out</a>
          </div>
        </div>
      </div>
    </div>

    
    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">

      <div class="container">
        <div class="d-flex align-items-center">
    
          <div class="mr-auto">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li class="active">
                  <a href="administrator.php" class="nav-link text-left">Home</a>
                </li>
                <li class="has-children">
                  <a href="#" class="nav-link text-left">Venue</a>
                  <ul class="dropdown">
                    <li><a href="AddV.php">Add Venue</a></li>
                    <li><a href="venue.php">Edit Venue</a></li>
					<li><a href="delV.php">Delete Venue</a></li>
                  </ul>
                </li>
                <li class="has-children">
                  <a href="#" class="nav-link text-left">Performer</a>
                  <ul class="dropdown">
                    <li><a href="addP.php">Add Performer</a></li>
                    <li><a href="perf.php">Edit Performer</a></li>
					<li><a href="delP.php">Delete Performer</a></li>
                  </ul>
                </li>
				<li class="has-children">
                  <a href="#" class="nav-link text-left">Our Organizer</a>
                  <ul class="dropdown">
                    <li><a href="addO.php">Add Organizer</a></li>
                    <li><a href="org.php">Edit Organizer</a></li>
					<li><a href="delO.php">Delete Organizer</a></li>
                  </ul>
                </li>
                <li class="has-children">
                  <a href="#" class="nav-link text-left">Schedule</a>
                  <ul class="dropdown">
                    <li><a href="addE.php">Add Event</a></li>
                    <li><a href="event.php">Edit Event</a></li>
					<li><a href="delE.php">Delete Event</a></li>
                  </ul>
                </li>
				 <li class="has-children">
                  <a href="#" class="nav-link text-left">User</a>
                  <ul class="dropdown">
                    <li><a href="addU.php">Add User</a></li>
                    <li><a href="customer.php">Edit User</a></li>
					<li><a href="delU.php">Delete User</a></li>
                  </ul>
                </li>
				<li class="has-children">
                  <a href="#" class="nav-link text-left">Accounts</a>
                  <ul class="dropdown">
                    <li><a href="accounts.php">Edit account</a></li>
					<li><a href="delA.php">Delete account</a></li>
                  </ul>
                </li>
              </ul>                                                                                                                                                                                                                                                                                          </ul>
            </nav>

          </div>
          <div class="ml-auto">
            <div class="social-wrap">
              <a href="#"><span class="icon-facebook"></span></a>
              <a href="#"><span class="icon-twitter"></span></a>
              <a href="#"><span class="icon-linkedin"></span></a>

              <a href="#" class="d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black"><span
                class="icon-menu h3"></span></a>
            </div>
          </div>
         
        </div>
      </div>

    <div class="site-section">
        <div class="container">
		<div class="site-section">
      <div class="container">
        <div class="row mb-5 justify-content-center text-center">
          <div class="col-lg-4 mb-5">
            <h2 class="section-title-underline mb-5">
              <span>Update Event</span>
            </h2>
          </div>
        </div>
		<form action="searchE.php" method="POST">
		<div class="col-md-6 form-group">
                   <input type="text" class="form-control" id="Name" name="Name" placeholder='Search by Event Name given below'  required>
                <div class="col-12">
                    <input type="submit" value="Search" class="btn btn-primary btn-lg px-5">
                </div>
            </div>
                    </form><br><br>

                    
         <?php
                    $Name=$_POST['Name'];
                    $sql = 'SELECT * FROM schedule WHERE Name=?' or die ('Error! Could not run query: '.$conn->error);
                    $stmt = $conn->prepare($sql);
					$stmt->bind_param('s',$Name);
					$stmt->execute();
					$result = $stmt->get_result();
					$num_rows = $result->num_rows;
					if($num_rows == 1){
                        echo "<table class='table table-list-search' id='myTable'>";
                        
                        echo "<tr class='tableHead'>";
                        echo "<th>Type</th>";
                        echo "<th> Name</th>";
                        echo "<th></th>";
                        echo "</tr>";
                      
                        while ($rows = $result->fetch_assoc()){
                            $id = $rows["SID"];
                            echo "<tr>
                                    <td>".$rows["Type"]. "</td>
									<td>".$rows["Name"]. "</td>
                                    <td><a href='updateE.php?id=".$rows["SID"]."'>Update</a></td><br>
                                    <td><a href='removeE.php?id=".$rows["SID"]."'>Remove</a></td>
                                </tr>";
                               
                        }
                    
                        echo "</table>";
                    }
                    else {
                        echo ('Error! Could not run query '.$conn->error);
                    }
                ?>
        </div>
    </div>


  </div>
 

  <script src="js/main.js"></script>

</body>

</html>