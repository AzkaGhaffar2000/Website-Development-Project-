-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Sep 30, 2020 at 07:10 PM
-- Server version: 5.7.26
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `ent`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `AccID` int(11) UNSIGNED NOT NULL,
  `username` varchar(60) NOT NULL DEFAULT '',
  `password` varchar(60) NOT NULL DEFAULT '',
  `aType` int(1) UNSIGNED ZEROFILL DEFAULT NULL,
  `OID` int(11) UNSIGNED DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`AccID`, `username`, `password`, `aType`, `OID`) VALUES
(1, 'azka', '$2y$10$lbH2C3TrOmHinLPf134pvewyabqk5002fI63A4b0mIgaKvsnTz3ty', 1, 0),
(3, 'TEST', '$2y$10$s6Y2w8/KdYv9E6CWUu7UyuZolw42UugCr2enGtcW4p8yNn/u5YI8m', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `organizer`
--

CREATE TABLE `organizer` (
  `OID` int(11) UNSIGNED NOT NULL,
  `PfirstName` varchar(15) NOT NULL DEFAULT '',
  `PlastName` varchar(20) NOT NULL DEFAULT '',
  `tel` varchar(15) DEFAULT NULL,
  `Pemail` varchar(40) NOT NULL DEFAULT '',
  `fee` decimal(5,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `organizer`
--

INSERT INTO `organizer` (`OID`, `PfirstName`, `PlastName`, `tel`, `Pemail`, `fee`) VALUES
(1, 'Katherine', 'Fisher', '100-122-2349', 'kat@planit.abc', '100.00'),
(2, 'Mike', 'James', '123-456-7890', 'mike@planit.abc', '600.00');

-- --------------------------------------------------------

--
-- Table structure for table `performer`
--

CREATE TABLE `performer` (
  `PID` int(11) UNSIGNED NOT NULL,
  `FName` varchar(15) NOT NULL DEFAULT '',
  `LName` varchar(20) NOT NULL DEFAULT '',
  `description` varchar(20) NOT NULL DEFAULT '',
  `fee` decimal(10,2) NOT NULL,
  `expectedSize` int(11) NOT NULL,
  `telNo` varchar(15) DEFAULT '',
  `email` varchar(40) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `performer`
--

INSERT INTO `performer` (`PID`, `FName`, `LName`, `description`, `fee`, `expectedSize`, `telNo`, `email`) VALUES
(1, 'James', 'Ried', 'singer', '10000.00', 15000, '111-222-3333', 'james@perf.olj'),
(2, 'John', 'Adams', 'magician', '8000.00', 10000, '222-555-9999', 'adams@artist.abc');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `SID` int(11) UNSIGNED NOT NULL,
  `Type` varchar(256) NOT NULL DEFAULT '',
  `Name` varchar(256) NOT NULL DEFAULT '',
  `Expected` int(11) NOT NULL,
  `Actual` int(11) DEFAULT NULL,
  `StartD` date NOT NULL,
  `EndD` date NOT NULL,
  `StartT` time NOT NULL,
  `EndT` time NOT NULL,
  `Notes` text,
  `ticket` decimal(10,2) NOT NULL,
  `Profit` decimal(10,2) DEFAULT NULL,
  `pMaterials` text,
  `UID` int(11) UNSIGNED DEFAULT NULL,
  `PID` int(11) UNSIGNED DEFAULT NULL,
  `VID` int(11) UNSIGNED DEFAULT NULL,
  `OID` int(11) UNSIGNED DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`SID`, `Type`, `Name`, `Expected`, `Actual`, `StartD`, `EndD`, `StartT`, `EndT`, `Notes`, `ticket`, `Profit`, `pMaterials`, `UID`, `PID`, `VID`, `OID`) VALUES
(1, 'Wedding', 'Steven Weds Kat', 300, 300, '2020-02-10', '2020-02-10', '17:00:00', '21:00:00', 'notes', '20.00', '8000.00', 'wedding cards', 2, 1, 2, 1),
(2, 'Birthday', '18th Birthday', 100, 87, '2019-11-30', '2020-11-30', '14:00:00', '19:00:00', 'Custom Decorations', '50.00', '3000.00', 'social media promotions', 2, 2, 2, 2),
(6, 'Concert', 'Final Tour', 1000, 996, '2020-05-15', '2020-05-15', '18:00:00', '22:00:00', 'Special lights and fireworks', '300.00', '15000.00', 'social media', 1, 1, 2, 1),
(7, 'jskdnks', 'adnmsn', 100, 100, '2020-10-11', '2020-10-11', '01:00:00', '01:00:00', 'ndmas', '20.00', '2000.00', 'nfmd,', NULL, NULL, NULL, NULL),
(8, 'wnme', 'erben', 10, 10, '2020-11-11', '2020-11-11', '12:00:00', '16:00:00', 'ajksd', '20.00', '1000.00', 'sadmsn', 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UID` int(11) UNSIGNED NOT NULL,
  `firstName` varchar(15) NOT NULL DEFAULT '',
  `lastName` varchar(20) NOT NULL DEFAULT '',
  `phone` varchar(15) DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `street` varchar(80) NOT NULL DEFAULT '',
  `city` varchar(40) NOT NULL DEFAULT '',
  `state` varchar(2) NOT NULL DEFAULT '',
  `zipCode` varchar(11) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UID`, `firstName`, `lastName`, `phone`, `email`, `street`, `city`, `state`, `zipCode`) VALUES
(1, 'Joseph', 'Brown', '100-111-0011', 'brown@abc.com', '98 hello street', 'New Rochelle', 'NY', '10201'),
(2, 'Chris', 'Kim', '122-341-1020', 'chris@gbl.com', '65 sleep avenue', 'New Rochelle', 'NY', '10205');

-- --------------------------------------------------------

--
-- Table structure for table `venue`
--

CREATE TABLE `venue` (
  `VID` int(11) UNSIGNED NOT NULL,
  `Name` varchar(50) NOT NULL DEFAULT '',
  `Capacity` bigint(225) NOT NULL,
  `Cost` decimal(9,2) UNSIGNED NOT NULL,
  `TelPhone` varchar(15) NOT NULL DEFAULT '',
  `Vemail` varchar(40) NOT NULL DEFAULT '',
  `Vstreet` varchar(80) NOT NULL DEFAULT '',
  `Vcity` varchar(40) NOT NULL DEFAULT '',
  `Vstate` varchar(2) NOT NULL DEFAULT '',
  `VzipCode` varchar(11) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `venue`
--

INSERT INTO `venue` (`VID`, `Name`, `Capacity`, `Cost`, `TelPhone`, `Vemail`, `Vstreet`, `Vcity`, `Vstate`, `VzipCode`) VALUES
(1, 'CitiField', 20000, '1000.00', '100-999-6734', 'citifield@mail.org', '567 lincoln street', 'New York', 'NY', '18902'),
(2, 'Plaza Hotel', 1000, '50.00', '111-322-3283', 'plaza@plaza.abc', '182 main street', 'New York', 'NY', '18127');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`AccID`),
  ADD KEY `OrganizerID` (`OID`);

--
-- Indexes for table `organizer`
--
ALTER TABLE `organizer`
  ADD PRIMARY KEY (`OID`);

--
-- Indexes for table `performer`
--
ALTER TABLE `performer`
  ADD PRIMARY KEY (`PID`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`SID`),
  ADD KEY `Event_UID_fk` (`UID`),
  ADD KEY `Event_PID_fk` (`PID`),
  ADD KEY `Event_VID_fk` (`VID`),
  ADD KEY `Event_OID_fk` (`OID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UID`);

--
-- Indexes for table `venue`
--
ALTER TABLE `venue`
  ADD PRIMARY KEY (`VID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `AccID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `organizer`
--
ALTER TABLE `organizer`
  MODIFY `OID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `performer`
--
ALTER TABLE `performer`
  MODIFY `PID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `SID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `venue`
--
ALTER TABLE `venue`
  MODIFY `VID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
