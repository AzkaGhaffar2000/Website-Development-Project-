<?php
include("ConnectEntDB.php");

$id = $_REQUEST['id'];
$delete="delete from schedule WHERE SID=$id"; 

$result = $conn->query($delete) or die('Error:could not run query: '.$conn->error.$id);
header("Location: event.php"); 
?>