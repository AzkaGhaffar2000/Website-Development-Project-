<?php
		include("ConnectEntDB.php");
			$PID=$_POST["PID"];
            $FName=$_POST["FName"];
            $LName=$_POST["LName"];
            $description=$_POST["description"];
            $fee=$_POST["fee"];
            $expectedSize=$_POST["expectedSize"];
            $telNo=$_POST["telNo"];
            $email=$_POST["email"];
			

            $sql = "UPDATE performer SET FName='$FName', LName='$LName', description='$description', fee='$fee', expectedSize='$expectedSize', telNo='$telNo', email='$email' WHERE PID ='$PID';";
            
            $res1 = $conn->query($sql) or die('Error: could not run query: '.$conn->error);
            echo "<h2 style='text-align:center'>Performer Updated.<h2>";
            $conn->close();
            header("Location:perf.php");
        ?>