<?php
    include("ConnectEntDB.php");
?>
<?php

            $name=$_POST["Name"];
            $name = $conn->real_escape_string($name);
			$capacity=$_POST["Capacity"];
            $capacity = $conn->real_escape_string($capacity);
            $cost=$_POST["Cost"];   
            $cost = $conn->real_escape_string($cost);
            $phone=$_POST["TelPhone"];
            $phone = $conn->real_escape_string($phone);
            $email=$_POST["Vemail"];
            $email = $conn->real_escape_string($email);
            $street=$_POST["Vstreet"];
            $street = $conn->real_escape_string($street);
			$city=$_POST["Vcity"];
            $city = $conn->real_escape_string($city);
			 $state=$_POST["Vstate"];
            $state = $conn->real_escape_string($state);
			 $zip=$_POST["VzipCode"];
            $zip = $conn->real_escape_string($zip);

            $sqlven = "INSERT INTO venue (`Name`,`Capacity`, `Cost`, `TelPhone`, `Vemail`, `Vstreet`, `Vcity`, `Vstate`, `VzipCode`) 
            VALUES ('$name', '$capacity', '$cost','$phone','$email', '$street', '$city','$state','$zip')";
            
            $res = $conn->query($sqlven) or die('Error: could not run query: '.$conn->error);
            echo "<h2 style='text-align:center'>Venue Updated.<h2>";
            $conn->close();
            header("Location:AddV.php");
            
        
        ?>