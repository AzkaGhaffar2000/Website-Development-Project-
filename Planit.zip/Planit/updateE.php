<?php 
	session_start();
    
    include("ConnectEntDB.php");

	if (isset($_SESSION['AccID']))
	{
        $AccountID = $_SESSION['AccID'];
	}
	else
	{
		header("Location:logout.php");
	}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>PlanIT</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="fonts/icomoon/style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/jquery-ui.css">

  <link rel="stylesheet" href="css/style.css">



</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">
  
	<div class="py-2 bg-light">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-3 text-right">
            <a href="logout.php" class="small mr-3"><span class="icon-unlock-alt"></span> Log Out</a>
          </div>
        </div>
      </div>
    </div>

    
    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">

      <div class="container">
        <div class="d-flex align-items-center">
    
          <div class="mr-auto">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li class="active">
                  <a href="administrator.php" class="nav-link text-left">Home</a>
                </li>
                <li class="has-children">
                  <a href="#" class="nav-link text-left">Venue</a>
                  <ul class="dropdown">
                    <li><a href="AddV.php">Add Venue</a></li>
                    <li><a href="venue.php">Edit Venue</a></li>
					<li><a href="delV.php">Delete Venue</a></li>
                  </ul>
                </li>
                <li class="has-children">
                  <a href="#" class="nav-link text-left">Performer</a>
                  <ul class="dropdown">
                    <li><a href="addP.php">Add Performer</a></li>
                    <li><a href="perf.php">Edit Performer</a></li>
					<li><a href="delP.php">Delete Performer</a></li>
                  </ul>
                </li>
				<li class="has-children">
                  <a href="#" class="nav-link text-left">Our Organizer</a>
                  <ul class="dropdown">
                    <li><a href="addO.php">Add Organizer</a></li>
                    <li><a href="org.php">Edit Organizer</a></li>
					<li><a href="delO.php">Delete Organizer</a></li>
                  </ul>
                </li>
                <li class="has-children">
                  <a href="#" class="nav-link text-left">Schedule</a>
                  <ul class="dropdown">
                    <li><a href="addE.php">Add Event</a></li>
                    <li><a href="event.php">Edit Event</a></li>
					<li><a href="delE.php">Delete Event</a></li>
                  </ul>
                </li>
				 <li class="has-children">
                  <a href="#" class="nav-link text-left">User</a>
                  <ul class="dropdown">
                    <li><a href="addU.php">Add User</a></li>
                    <li><a href="customer.php">Edit User</a></li>
					<li><a href="delU.php">Delete User</a></li>
                  </ul>
                </li>
				<li class="has-children">
                  <a href="#" class="nav-link text-left">Accounts</a>
                  <ul class="dropdown">
                    <li><a href="accounts.php">Edit account</a></li>
					<li><a href="delA.php">Delete account</a></li>
                  </ul>
                </li>
              </ul>                                                                                                                                                                                                                                                                                          </ul>
            </nav>

          </div>
          <div class="ml-auto">
            <div class="social-wrap">
              <a href="#"><span class="icon-facebook"></span></a>
              <a href="#"><span class="icon-twitter"></span></a>
              <a href="#"><span class="icon-linkedin"></span></a>

              <a href="#" class="d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black"><span
                class="icon-menu h3"></span></a>
            </div>
          </div>
         
        </div>
      </div>
    <div class="site-section">
        <div class="container">
		<div class="site-section">
      <div class="container">
        <div class="row mb-5 justify-content-center text-center">
          <div class="col-lg-4 mb-5">
            <h2 class="section-title-underline mb-5">
              <span>Update event</span>
            </h2>
          </div>
        </div>
		<?php
            include("ConnectEntDB.php");
            $SID=$_REQUEST["id"];

           $sql = "SELECT * FROM schedule JOIN user on user.`UID` = schedule.`UID` JOIN performer on performer.`PID` = schedule.`PID` JOIN venue on venue.`VID`=schedule.`VID` JOIN organizer on organizer.`OID`=schedule.`OID` where schedule.`SID`='$SID'";
            $res = $conn->query($sql) or die('Error: Could not run query: '.$conn->error);

            if ($res->num_rows > 0) {
                while ($row = $res->fetch_assoc()) {
                    $UID = $row['UID'];
                    $PID = $row['PID'];
                    $VID = $row['VID'];
					$OID = $row['OID'];
                    echo "<form action='updatedE.php' method='POST'>"; 
                    echo "<div class='row'>";
                    echo "<div class='col-md-6 form-group'>";
                    echo "<label for='SID' >Event ID:</label>";
                    echo "<input type='text' type='hidden' class='form-control' id='SID' name='SID' value='".$_REQUEST['id']."' readonly>";
                    echo "</div>";
                    echo "<div class='col-md-6 form-group'>";
                    echo "<label for='Type'>Type:</label>";
                    echo "<input type='text' class='form-control' id='Type' name='Type' value='".$row["Type"]."'>";
                    echo "</div>";
                    echo "</div>";

                    echo "<div class='row'>";
                    echo "<div class='col-md-6 form-group'>";
                    echo "<label for='Name' > Name:</label>";
                    echo "<input type='text' class='form-control' id='Name' name='Name' value='".$row["Name"]."'>";
                    echo "</div>";
                    echo "<div class='col-md-6 form-group'>";
                    echo "<label for='Expected'>Expected:</label>";
                    echo "<input type='text' class='form-control' id='Expected' name='Expected' value='".$row["Expected"]."'>";
                    echo "</div>";
                    echo "</div>";
					
                    echo "<div class='row'>";
                    echo "<div class='col-md-6 form-group'>";
                    echo "<label for='Actual' >Actual:</label>";
                    echo "<input type='text' class='form-control' id='Actual' name='Actual' value='".$row["Actual"]."'>";
                    echo "</div>";
                    echo "<div class='col-md-6 form-group'>";
                    echo "<label for='StartD'>Start Date:</label>";
                    echo "<input type='text' class='form-control' id='StartD' name='StartD' value='".$row["StartD"]."'>";
                    echo "</div>";
                    echo "</div>";

					echo "<div class='row'>";
                    echo "<div class='col-md-6 form-group'>";
                    echo "<label for='EndD' >End date:</label>";
                    echo "<input type='text' class='form-control' id='EndD' name='EndD' value='".$row["EndD"]."'>";
                    echo "</div>";
                    echo "<div class='col-md-6 form-group'>";
                    echo "<label for='StartT'>Start Time:</label>";
                    echo "<input type='text' class='form-control' id='StartT' name='StartT' value='".$row["StartT"]."'>";
                    echo "</div>";
                    echo "</div>";
					
					echo "<div class='row'>";
                    echo "<div class='col-md-6 form-group'>";
                    echo "<label for='EndT' >End Time:</label>";
                    echo "<input type='text' class='form-control' id='EndT' name='EndT' value='".$row["EndT"]."'>";
                    echo "</div>";
                    echo "<div class='col-md-6 form-group'>";
                    echo "<label for='ticket'>ticket:</label>";
                    echo "<input type='text' class='form-control' id='ticket' name='ticket' value='".$row["ticket"]."'>";
                    echo "</div>";
                    echo "</div>";
					
					echo "<div class='row'>";
                    echo "<div class='col-md-6 form-group'>";
                    echo "<label for='Profit' >Profit:</label>";
                    echo "<input type='text' class='form-control' id='Profit' name='Profit' value='".$row["Profit"]."'>";
                    echo "</div>";
                    echo "<div class='col-md-6 form-group'>";
                    echo "<label for='Notes'>Notes:</label>";
                    echo "<input type='text' class='form-control' id='Notes' name='Notes' value='".$row["Notes"]."'>";
                    echo "</div>";
                    echo "</div>";
					
					echo "<div class='row'>";
                    echo "<div class='col-md-6 form-group'>";
                    echo "<label for='pMaterials' >Promotions:</label>";
                    echo "<input type='text' class='form-control' id='pMaterials' name='pMaterials' value='".$row["pMaterials"]."'>";
                    echo "</div>";
                    echo "<div class='col-md-6 form-group'>";
                    echo "<label for='userID'>User:</label>";
                    echo  "<select name='userID'>";
                    
                    $cus = "SELECT UID,firstName,lastName FROM user";
                    $result = $conn->query($cus) or die('Error! Cound not run query: '.$conn->error);
                    if ($result->num_rows > 0){
                      while ($row=$result->fetch_assoc()){
                          if ($row["UID"] === $UID){
                              echo "<option value='".$row["UID"]."' selected>".$row["firstName"]." ".$row["lastName"]."</option>";
                          }
                          else {echo "
                            <option value='".$row["UID"]."'>".$row["firstName"]." ".$row["lastName"]."</option>'";}
                        
                       
                    
                      }
                    }

                    echo "</select>
                        </div>
                        </div> <br>";
					
					echo "<div class='row'>";
					echo "<div class='col-md-6 form-group'>";
                    echo "<label for='venID'>Venue:</label>";
                    echo  "<select name='venID'>";
                    
                    $ven = "SELECT VID,Name FROM venue";
                    $result = $conn->query($ven) or die('Error! Cound not run query: '.$conn->error);
                    if ($result->num_rows > 0){
                      while ($row=$result->fetch_assoc()){
                          if ($row["VID"] === $VID){
                              echo "<option value='".$row["VID"]."' selected>".$row["Name"]." </option>";
                          }
                          else {echo "
                            <option value='".$row["VID"]."'>".$row["Name"]." </option>'";}
                        
                       
                    
                      }
                    }

                    echo "</select>";
                    echo "<div class='col-md-6 form-group'>";
                    echo "<label for='perfID'>Perfomer:</label>";
                    echo  "<select name='perfID'>";
                    
                    $perf = "SELECT PID,FName,LName FROM performer";
                    $result = $conn->query($perf) or die('Error! Cound not run query: '.$conn->error);
                    if ($result->num_rows > 0){
                      while ($row=$result->fetch_assoc()){
                          if ($row["PID"] === $PID){
                              echo "<option value='".$row["PID"]."' selected>".$row["FName"]." ".$row["LName"]."</option>";
                          }
                          else {echo "
                            <option value='".$row["PID"]."'>".$row["FName"]." ".$row["LName"]."</option>'";}
                        
                       
                    
                      }
                    }

                    echo "</select>
                        </div>
                        </div> <br>";
					echo "<div class='row'>";
					echo "<div class='col-md-6 form-group'>";
                    echo "<label for='orgID'>Organizer:</label>";
                    echo  "<select name='orgID'>";
                    
                    $org = "SELECT OID,PfirstName,PlastName FROM organizer";
                    $result = $conn->query($org) or die('Error! Cound not run query: '.$conn->error);
                    if ($result->num_rows > 0){
                      while ($row=$result->fetch_assoc()){
                          if ($row["OID"] === $OID){
                              echo "<option value='".$row["OID"]."' selected>".$row["PfirstName"]." ".$row["PlastName"]."</option>";
                          }
                          else {echo "
                            <option value='".$row["OID"]."'>".$row["PfirstName"]." ".$row["PlastName"]."</option>'";}
                        
                       
                    
                      }
                    }

                    echo "</select>
                        </div>
                        </div>";
                }
				echo "<div class='row'>";
					echo "<div class='col-12'>";
                     echo "<input type='submit'>";
			        echo "</form>";
					echo "</div>";
                    echo "</div>";
            }
            else {
                echo "0 results";
            }
			$conn->close();
		?>
        </div>
    </div>

</div>
  </div>

  <script src="js/main.js"></script>

</body>

</html>