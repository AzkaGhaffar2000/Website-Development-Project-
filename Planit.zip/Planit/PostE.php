<?php
    include("ConnectEntDB.php");
?>
<?php

            $Type=$_POST["Type"];
            $Type = $conn->real_escape_string($Type);
			$Name=$_POST["Name"];
            $Name = $conn->real_escape_string($Name);
            $Expected=$_POST["Expected"];   
            $Expected = $conn->real_escape_string($Expected);
            $Actual=$_POST["Actual"];
            $Actual = $conn->real_escape_string($Actual);
            $StartD=$_POST["StartD"];
            $StartD = $conn->real_escape_string($StartD);
            $EndD=$_POST["EndD"];
            $EndD = $conn->real_escape_string($EndD);
			$StartT=$_POST["StartT"];
            $StartT = $conn->real_escape_string($StartT);
			 $EndT=$_POST["EndT"];
            $EndT = $conn->real_escape_string($EndT);
			 $ticket=$_POST["ticket"];
            $ticket = $conn->real_escape_string($ticket);
			 $Profit=$_POST["Profit"];
            $Profit = $conn->real_escape_string($Profit);
			 $Notes=$_POST["Notes"];
            $Notes = $conn->real_escape_string($Notes);
			 $pMaterials=$_POST["pMaterials"];
            $pMaterials = $conn->real_escape_string($pMaterials);
			$user=$_POST['userID'];
            $user = $conn->real_escape_string($user);
            $perf=$_POST['perfID'];
            $perf = $conn->real_escape_string($perf);
            $venue=$_POST['venID'];
            $venue = $conn->real_escape_string($venue);
			$org=$_POST['orgID'];
            $org = $conn->real_escape_string($org);
			

			$check = "SELECT * FROM schedule
            WHERE EndT<'$EndT' AND StartT>'$StartT' AND StartD='$StartD'and (PID=$perf OR VID=$venue);";

            $verify = $conn->query($check) or die('Error: could not run query: '.$conn->error);

            $count = 0;
            while ($row=$verify->fetch_assoc()) { 
                $count++;
            }
            $checkagain = "SELECT * FROM schedule 
            WHERE StartT<='$EndT' 
            AND EndT>='$StartT' 
            AND StartD='$StartD'
			AND (PID=$perf OR VID=$venue)";
			
            $VerifyCheck = $conn->query($checkagain) or die('Error: could not run query: '.$conn->error);

            while ($row=$VerifyCheck->fetch_assoc()) {
                $count++;
            }

            if ($count != 0){
                echo "<span style='color:black'>Venue or Performer not available on this date at this time, please try another date or time.</span><br>\n";
                sleep(5);
                header("Location:AddE.php");
            }
            else {

            $sql= "INSERT INTO schedule(`Type`,`Name`, `Expected`, `Actual`, `StartD`, `EndD`, `StartT`, `EndT`, `ticket`, `Profit`,  `Notes`, `pMaterials`, `UID`,`PID`,`VID`,`OID`) 
            VALUES ('$Type', '$Name', '$Expected','$Actual','$StartD', '$EndD', '$StartT','$EndT','$ticket','$Profit',  '$Notes','$pMaterials','$user','$perf', '$venue', '$org');";
            
            $res = $conn->query($sql) or die('Error: could not run query: '.$conn->error);
            echo "<h2 style='text-align:center'>Event Updated.<h2>";
            $conn->close();
            header("Location:AddE.php");
            }
            
        
        ?>