<?php
    include("ConnectEntDB.php");
?>
<?php

            $PfirstName=$_POST["PfirstName"];
            $PfirstName = $conn->real_escape_string($PfirstName);
			$PlastName=$_POST["PlastName"];
            $PlastName = $conn->real_escape_string($PlastName);
            $tel=$_POST["tel"];   
            $tel = $conn->real_escape_string($tel);
            $Pemail=$_POST["Pemail"];
            $Pemail = $conn->real_escape_string($Pemail);
            $fee=$_POST["fee"];
            $fee = $conn->real_escape_string($fee);
      

            $sqlorg = "INSERT INTO organizer (`PfirstName`,`PlastName`, `tel`, `Pemail`, `fee`) 
            VALUES ('$PfirstName', '$PlastName', '$tel','$Pemail','$fee')";
            
            $res = $conn->query($sqlorg) or die('Error: could not run query: '.$conn->error);
            echo "<h2 style='text-align:center'>Organizer Updated.<h2>";
            $conn->close();
            header("Location:addO.php");
            
        
        ?>