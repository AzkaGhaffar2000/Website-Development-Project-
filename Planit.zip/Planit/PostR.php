<?php
    include("ConnectEntDB.php");
?>
<?php

            $username=$_POST["username"];
            $username = $conn->real_escape_string($username);
			$password=$_POST["password"];
            $password = $conn->real_escape_string($password);
            $aType=$_POST["aType"];   
            $aType = $conn->real_escape_string($aType);
            $org=$_POST['orgID'];
            $org = $conn->real_escape_string($org);
			$hash = password_hash($password, PASSWORD_BCRYPT);

            $sqlorg = "INSERT INTO account (`username`,`password`, `aType`, `OID`) 
            VALUES ('$username', '$hash', '$aType','$org')";
            
            $res = $conn->query($sqlorg) or die('Error: could not run query: '.$conn->error);
            echo "<h2 style='text-align:center'>Registered<h2>";
            $conn->close();
            header("Location:administrator.php");
            
        
        ?>