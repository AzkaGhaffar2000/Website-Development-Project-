<?php
		include("ConnectEntDB.php");
			$UID=$_POST["UID"];
            $firstName=$_POST["firstName"];
            $lastName=$_POST["lastName"];
            $phone=$_POST["phone"];
            $email=$_POST["email"];
            $street=$_POST["street"];
            $city=$_POST["city"];
            $state=$_POST["state"];
			$zipCode=$_POST["zipCode"];
			

            $sql = "UPDATE user SET firstName='$firstName', lastName='$lastName', phone='$phone', email='$email', street='$street', city='$city', state='$state', zipCode='$zipCode' WHERE UID ='$UID';";
            
            $res1 = $conn->query($sql) or die('Error: could not run query: '.$conn->error);
            echo "<h2 style='text-align:center'>User Updated.<h2>";
            $conn->close();
            header("Location:customer.php");
        ?>