<?php
		include("ConnectEntDB.php");
			$VID=$_POST["VID"];
            $Name=$_POST["Name"];
            $Capacity=$_POST["Capacity"];
            $Cost=$_POST["Cost"];
            $TelPhone=$_POST["TelPhone"];
            $Vemail=$_POST["Vemail"];
            $Vstreet=$_POST["Vstreet"];
            $Vcity=$_POST["Vcity"];
			$Vstate=$_POST["Vstate"];
			$VzipCode=$_POST["VzipCode"];

            $sql = "UPDATE venue SET Name='$Name', Capacity='$Capacity', Cost='$Cost', TelPhone='$TelPhone', Vemail='$Vemail', Vstreet='$Vstreet', Vcity='$Vcity', Vstate='$Vstate', VzipCode='$VzipCode'  WHERE VID ='$VID';";
            
            $res1 = $conn->query($sql) or die('Error: could not run query: '.$conn->error);
            echo "<h2 style='text-align:center'>Venue Updated.<h2>";
            $conn->close();
            header("Location:venue.php");
        ?>