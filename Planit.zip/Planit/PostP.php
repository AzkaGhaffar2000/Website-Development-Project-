<?php
    include("ConnectEntDB.php");
?>
<?php

            $FName=$_POST["FName"];
            $FName = $conn->real_escape_string($FName);
			$LName=$_POST["LName"];
            $LName = $conn->real_escape_string($LName);
            $description=$_POST["description"];   
            $description = $conn->real_escape_string($description);
            $fee=$_POST["fee"];
            $fee = $conn->real_escape_string($fee);
            $expectedSize=$_POST["expectedSize"];
            $expectedSize = $conn->real_escape_string($expectedSize);
            $telNo=$_POST["telNo"];
            $telNo = $conn->real_escape_string($telNo);
			$email=$_POST["email"];
            $email = $conn->real_escape_string($email);

            $sqlperf = "INSERT INTO performer (`FName`,`LName`, `description`, `fee`, `expectedSize`, `telNo`, `email`) 
            VALUES ('$FName', '$LName', '$description','$fee','$expectedSize', '$telNo', '$email')";
            
            $res = $conn->query($sqlperf) or die('Error: could not run query: '.$conn->error);
            echo "<h2 style='text-align:center'>Performer Updated.<h2>";
            $conn->close();
            header("Location:addP.php");
            
        
        ?>