<?php
    include("ConnectEntDB.php");
?>
<?php

            $firstName=$_POST["firstName"];
            $firstName = $conn->real_escape_string($firstName);
			$lastName=$_POST["lastName"];
            $lastName = $conn->real_escape_string($lastName);
            $email=$_POST["email"];
            $email = $conn->real_escape_string($email);
            $street=$_POST["street"];
            $street = $conn->real_escape_string($street);
			$city=$_POST["city"];
            $city = $conn->real_escape_string($city);
			 $state=$_POST["state"];
            $state = $conn->real_escape_string($state);
			 $zip=$_POST["zipCode"];
            $zip = $conn->real_escape_string($zip);
			$phone=$_POST["phone"];
            $phone = $conn->real_escape_string($phone);

            $sqluser = "INSERT INTO user (`firstName`,`lastName`, `email`, `street`, `city`, `state`, `zipCode`, `phone`) 
            VALUES ('$firstName', '$lastName','$email', '$street', '$city','$state','$zip', '$phone')";
            
            $res = $conn->query($sqluser) or die('Error: could not run query: '.$conn->error);
            echo "<h2 style='text-align:center'>User Updated.<h2>";
            $conn->close();
            header("Location:addU.php");
            
        
        ?>