<?php
		include("ConnectEntDB.php");
			$OID=$_POST["OID"];
            $PfirstName=$_POST["PfirstName"];
            $PlastName=$_POST["PlastName"];
            $tel=$_POST["tel"];
            $Pemail=$_POST["Pemail"];
            $fee=$_POST["fee"];
        

            $sql = "UPDATE organizer SET PfirstName='$PfirstName', PlastName='$PlastName', tel='$tel', Pemail='$Pemail', fee='$fee' WHERE OID ='$OID';";
            
            $res1 = $conn->query($sql) or die('Error: could not run query: '.$conn->error);
            echo "<h2 style='text-align:center'>Organizer Updated.<h2>";
            $conn->close();
            header("Location:org.php");
        ?>